export interface Product
{
  id: number;
  price: number;
  name: string;
  imgUrl: string;
  description: string;
}
